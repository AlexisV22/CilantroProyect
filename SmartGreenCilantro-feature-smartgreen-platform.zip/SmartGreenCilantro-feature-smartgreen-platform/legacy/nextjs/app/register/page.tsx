export { default } from './reg'
